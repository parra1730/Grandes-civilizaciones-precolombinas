/* ============================================
   NAVEGACIÓN ENTRE PÁGINAS
============================================ */
function showPage(page){
    document.querySelectorAll(".page").forEach(function(section){
        section.classList.remove("active");
    });

    document.getElementById(page).classList.add("active");

    document.querySelectorAll(".nav-buttons button").forEach(function(button){
        button.classList.remove("active");
    });

    let selectedButton = document.getElementById("btn-" + page);
    if(selectedButton){
        selectedButton.classList.add("active");
    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

/* ============================================
   INFORMACIÓN DE ACTIVIDADES
============================================ */
const data = {
    maya:{
        quiz:[
            ["¿Cómo se organizaban políticamente muchas ciudades mayas?", "Como ciudades-estado"],
            ["¿Qué sistema de escritura desarrollaron los mayas?", "Un sistema de escritura jeroglífica"],
            ["¿Qué conocimientos desarrollaron ampliamente?", "Matemáticas y astronomía"],
            ["¿En qué región se desarrolló principalmente la civilización Maya?", "Mesoamérica"],
            ["¿Qué ocurre con los pueblos mayas actualmente?", "Conservan lenguas y tradiciones"]
        ],
        match:[
            ["Mesoamérica", "Región donde se desarrollaron los mayas"],
            ["Jeroglíficos", "Sistema de escritura maya"],
            ["Astronomía", "Estudio de los astros"],
            ["Ciudad-estado", "Forma de organización política"]
        ],
        sort:[
            "Comunidades sedentarias fortalecen la agricultura",
            "Comienza el periodo Clásico maya",
            "Florecen la escritura, astronomía y arquitectura",
            "Se producen transformaciones políticas y regionales",
            "Los españoles conquistan distintos territorios mayas",
            "Los pueblos mayas continúan conservando sus culturas"
        ]
    },
    azteca:{
        quiz:[
            ["¿Cuál fue la capital de los mexicas?", "México-Tenochtitlan"],
            ["¿Quiénes formaron la Triple Alianza?", "Tenochtitlan, Texcoco y Tlacopan"],
            ["¿Qué actividades formaban parte de su economía?", "Agricultura, comercio y tributos"],
            ["¿Qué ocurrió en 1521?", "Cayó México-Tenochtitlan"],
            ["¿Dónde se encontraba Tenochtitlan?", "En el Valle de México"]
        ],
        match:[
            ["Tenochtitlan", "Capital de los mexicas"],
            ["Triple Alianza", "Alianza entre tres centros políticos"],
            ["Tributo", "Entrega de bienes o recursos"],
            ["Valle de México", "Región donde se encontraba Tenochtitlan"]
        ],
        sort:[
            "Fundación tradicional de México-Tenochtitlan",
            "Formación de la Triple Alianza",
            "Expansión del poder mexica",
            "Llegada de Hernán Cortés",
            "Asedio de Tenochtitlan",
            "Caída de México-Tenochtitlan"
        ]
    },
    inca:{
        quiz:[
            ["¿Cómo llamaban los incas a su territorio?", "Tawantinsuyu"],
            ["¿Cuál era el principal centro político?", "Cusco"],
            ["¿Qué eran los quipus?", "Un sistema de cuerdas y nudos"],
            ["¿Qué técnica agrícola utilizaban en las montañas?", "Terrazas agrícolas"],
            ["¿Qué proceso transformó profundamente el poder inca?", "La conquista española"]
        ],
        match:[
            ["Tawantinsuyu", "Nombre del territorio inca"],
            ["Quipu", "Sistema de cuerdas y nudos"],
            ["Cusco", "Principal centro político"],
            ["Terrazas agrícolas", "Superficies escalonadas para cultivar"]
        ],
        sort:[
            "Surgimiento temprano del poder inca en Cusco",
            "Etapa de expansión asociada a Pachacuti",
            "Gran expansión del Tawantinsuyu",
            "Captura de Atahualpa",
            "Toma de Cusco",
            "Transformación del poder imperial"
        ]
    }
};

/* ============================================
   RESULTADOS
============================================ */
const results = {
    maya: { quiz: null, match: null, sort: null },
    azteca: { quiz: null, match: null, sort: null },
    inca: { quiz: null, match: null, sort: null }
};

/* ============================================
   CREAR QUIZ
============================================ */
function renderQuiz(key){
    const container = document.getElementById(key + "Quiz");

    data[key].quiz.forEach(function(question, index){
        const div = document.createElement("div");
        div.className = "question";

        let correct = question[1];
        let options = data[key].quiz.map(q => q[1]).filter(answer => answer !== correct);
        options = options.slice(0, 3);
        options.push(correct);
        options.sort(() => Math.random() - 0.5);

        div.innerHTML = "<b>" + (index + 1) + ". " + question[0] + "</b>";

        options.forEach(function(option){
            div.innerHTML += `
                <label>
                    <input type="radio" name="${key}q${index}" value="${option}">
                    ${option}
                </label>
            `;
        });

        container.appendChild(div);
    });
}

/* ============================================
   CALIFICAR QUIZ
============================================ */
function gradeQuiz(key){
    let score = 0;

    data[key].quiz.forEach(function(question, index){
        let selected = document.querySelector(`input[name="${key}q${index}"]:checked`);
        if(selected && selected.value === question[1]){
            score++;
        }
    });

    results[key].quiz = score;
    document.getElementById(key + "QuizFeedback").textContent = "Resultado: " + score + "/5 respuestas correctas.";
    updateTotal(key);
}

/* ============================================
   CREAR RELACIONAR
============================================ */
function renderMatch(key){
    const container = document.getElementById(key + "Match");
    const definitions = data[key].match.map(item => item[1]).sort(() => Math.random() - 0.5);

    data[key].match.forEach(function(item, index){
        let html = `
            <div class="question">
                <b>${item[0]}</b>
                <select id="${key}m${index}">
                    <option value="">Selecciona una definición</option>
        `;

        definitions.forEach(function(definition){
            html += `<option value="${definition}">${definition}</option>`;
        });

        html += `</select></div>`;
        container.innerHTML += html;
    });
}

/* ============================================
   CALIFICAR RELACIONAR
============================================ */
function gradeMatch(key){
    let score = 0;

    data[key].match.forEach(function(item, index){
        let select = document.getElementById(key + "m" + index);
        if(select.value === item[1]){
            score++;
        }
    });

    results[key].match = score;
    document.getElementById(key + "MatchFeedback").textContent = "Resultado: " + score + "/" + data[key].match.length + " relaciones correctas.";
    updateTotal(key);
}

/* ============================================
   CREAR ORDENAMIENTO
============================================ */
function renderSort(key){
    const container = document.getElementById(key + "Sort");
    let events = [...data[key].sort];
    events.sort(() => Math.random() - 0.5);

    events.forEach(function(event){
        let div = document.createElement("div");
        div.className = "sort-item";
        div.textContent = event;

        div.onclick = function(){
            selectSort(div, key);
        };

        container.appendChild(div);
    });
}

/* ============================================
   INTERCAMBIAR ACONTECIMIENTOS
============================================ */
let selectedSort = {};

function selectSort(element, key){
    if(!selectedSort[key]){
        selectedSort[key] = element;
        element.classList.add("selected");
        return;
    }

    let first = selectedSort[key];
    let second = element;
    let parent = first.parentNode;

    let firstHTML = first.outerHTML;
    let secondHTML = second.outerHTML;

    first.outerHTML = secondHTML;
    second.outerHTML = firstHTML;

    parent.querySelectorAll(".sort-item").forEach(function(item){
        item.onclick = function(){
            selectSort(item, key);
        };
    });

    selectedSort[key] = null;
}

/* ============================================
   CALIFICAR ORDEN
============================================ */
function gradeSort(key){
    let items = [...document.querySelectorAll("#" + key + "Sort .sort-item")];
    let current = items.map(item => item.textContent);
    let correct = data[key].sort;
    let score = 0;

    current.forEach(function(item, index){
        if(item === correct[index]){
            score++;
        }
    });

    results[key].sort = score;
    document.getElementById(key + "SortFeedback").textContent = "Posiciones correctas: " + score + "/6.";
    updateTotal(key);
}

/* ============================================
   RESULTADO FINAL
============================================ */
function updateTotal(key){
    let r = results[key];
    let total = (r.quiz ?? 0) + (r.match ?? 0) + (r.sort ?? 0);
    let completed = [r.quiz, r.match, r.sort].filter(x => x !== null).length;
    let max = 5 + data[key].match.length + 6;
    let message = "";

    if(completed < 3){
        message = "Completa las tres actividades.";
    } else if(total >= max - 1){
        message = "Excelente comprensión histórica 🏆";
    } else if(total >= max - 3){
        message = "Muy buen trabajo 📚";
    } else if(total >= Math.ceil(max * .55)){
        message = "Buen trabajo. Puedes repasar algunos temas.";
    } else {
        message = "Te recomendamos repasar la información e intentarlo nuevamente.";
    }

    document.getElementById(key + "Total").textContent = "Resultado final: " + total + "/" + max + ". " + message;
}

/* ============================================
   INICIAR LAS ACTIVIDADES
============================================ */
["maya", "azteca", "inca"].forEach(function(key){
    renderQuiz(key);
    renderMatch(key);
    renderSort(key);
});

showPage("inicio");